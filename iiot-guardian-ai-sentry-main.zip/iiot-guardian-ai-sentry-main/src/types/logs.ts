
import { TrafficData } from "./traffic";

export interface LogEntry {
  id: string;
  timestamp: Date;
  data: TrafficData;
  result: number; // 0 for normal, 1 for intrusion
  confidence: number;
}
