
export interface TrafficData {
  packet_size: number;
  duration: number;
  protocol: number;
  src_bytes: number;
  dst_bytes: number;
  flag: number;
  wrong_fragment: number;
  urgent: number;
}
