
import { useState } from "react";
import Dashboard from "@/components/Dashboard";
import DataInputForm from "@/components/DataInputForm";
import { toast } from "@/hooks/use-toast";
import { TrafficData } from "@/types/traffic";
import { simulatePrediction } from "@/lib/mlSimulation";
import { LogEntry } from "@/types/logs";
import { 
  Shield, 
  ShieldAlert, 
  ShieldCheck, 
  AlertTriangle, 
  BarChart3, 
  Network, 
  LayoutDashboard,
  FileUp,
  Database
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/ThemeToggle";
import FileUpload from "@/components/FileUpload";
import DatasetPreviewModal from "@/components/DatasetPreviewModal";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const Index = () => {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [predictionResult, setPredictionResult] = useState<{
    prediction: number;
    confidence: number;
    timestamp: Date;
  } | null>(null);

  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [uploadedDataset, setUploadedDataset] = useState<TrafficData[]>([]);
  const [isDatasetModalOpen, setIsDatasetModalOpen] = useState(false);
  const [isBatchProcessing, setIsBatchProcessing] = useState(false);

  const handleAnalyzeTraffic = (data: TrafficData) => {
    // Set analyzing state
    setIsAnalyzing(true);
    
    // Simulate loading
    toast({
      title: "Analyzing traffic...",
      description: "Processing network metrics",
    });

    // Simulate ML model prediction (would be an API call in a real app)
    setTimeout(() => {
      const result = simulatePrediction(data);
      setPredictionResult(result);
      
      // Add to logs
      setLogs(prevLogs => [
        {
          id: crypto.randomUUID(),
          timestamp: result.timestamp,
          data,
          result: result.prediction,
          confidence: result.confidence
        },
        ...prevLogs.slice(0, 9) // Keep only 10 most recent logs
      ]);

      toast({
        title: result.prediction === 1 ? "⚠️ Intrusion Detected!" : "✅ Normal Traffic",
        description: `Confidence: ${(result.confidence * 100).toFixed(2)}%`,
        variant: result.prediction === 1 ? "destructive" : "default",
      });
      
      // End analyzing state
      setIsAnalyzing(false);
    }, 1500);
  };

  const handleDatasetLoaded = (data: TrafficData[]) => {
    setUploadedDataset(data);
    setIsDatasetModalOpen(true);
  };

  const handleBatchAnalyze = (dataset: TrafficData[]) => {
    setIsBatchProcessing(true);
    const batchSize = 10;
    const totalItems = dataset.length;
    let processedCount = 0;
    
    toast({
      title: "Starting batch analysis",
      description: `Processing ${totalItems} records...`,
    });

    // Clear existing logs before batch processing
    setLogs([]);
    
    // Process in batches to avoid freezing the UI
    const processBatch = (startIndex: number) => {
      const endIndex = Math.min(startIndex + batchSize, totalItems);
      
      for (let i = startIndex; i < endIndex; i++) {
        const data = dataset[i];
        const result = simulatePrediction(data);
        
        // Add to logs
        setLogs(prevLogs => [
          {
            id: crypto.randomUUID(),
            timestamp: new Date(),
            data,
            result: result.prediction,
            confidence: result.confidence
          },
          ...prevLogs
        ]);

        processedCount++;
        
        // Update the last prediction result
        if (i === totalItems - 1) {
          setPredictionResult(result);
        }
      }
      
      // Update progress
      const progress = Math.round((processedCount / totalItems) * 100);
      
      if (endIndex < totalItems) {
        // Process next batch
        setTimeout(() => {
          toast({
            title: "Batch processing",
            description: `Progress: ${progress}% (${processedCount}/${totalItems})`,
          });
          processBatch(endIndex);
        }, 100);
      } else {
        // Finished processing
        toast({
          title: "Batch analysis complete",
          description: `Processed ${totalItems} records`,
          variant: "default",
        });
        setIsBatchProcessing(false);
      }
    };
    
    // Start processing the first batch
    processBatch(0);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-200 dark:from-slate-900 dark:to-slate-800">
      <header className="bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 shadow-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-3">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg shadow-md">
                <Shield className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl md:text-3xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  IIoT Guardian AI Sentry
                  {predictionResult && (
                    predictionResult.prediction === 0 
                      ? <ShieldCheck className="h-5 w-5 text-green-500" /> 
                      : <ShieldAlert className="h-5 w-5 text-red-500 animate-pulse" />
                  )}
                </h1>
                <p className="text-slate-500 dark:text-slate-400">
                  Real-Time Intrusion Detection for Industrial IoT Networks
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <ThemeToggle />
              <Button variant="outline" size="sm" className="hidden md:flex items-center gap-2">
                <Network className="h-4 w-4" />
                <span>Network Status</span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-wrap items-center justify-between mb-6">
          <div className="flex items-center gap-2 mb-4 md:mb-0">
            <LayoutDashboard className="h-5 w-5 text-blue-500" />
            <h2 className="text-xl font-semibold text-slate-800 dark:text-slate-200">Command Center</h2>
          </div>
          <div className="flex gap-2 items-center">
            <div className="text-sm text-slate-500 dark:text-slate-400">
              {logs.length > 0 ? (
                <span className="flex items-center gap-1">
                  <BarChart3 className="h-4 w-4" />
                  {logs.length} traffic analysis records
                </span>
              ) : (
                <span className="flex items-center gap-1">
                  <AlertTriangle className="h-4 w-4" />
                  No traffic analyzed yet
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1">
            <Tabs defaultValue="manual" className="mb-6">
              <TabsList className="w-full">
                <TabsTrigger value="manual" className="flex-1">
                  Manual Input
                </TabsTrigger>
                <TabsTrigger value="dataset" className="flex-1">
                  Import Dataset
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="manual" className="pt-6">
                <DataInputForm onSubmit={handleAnalyzeTraffic} isAnalyzing={isAnalyzing} />
              </TabsContent>
              
              <TabsContent value="dataset" className="pt-6">
                <div className="bg-white dark:bg-slate-800 rounded-lg shadow-md border border-slate-200 dark:border-slate-700 overflow-hidden transition-all duration-200 hover:shadow-lg">
                  <div className="bg-gradient-to-r from-purple-600 to-indigo-600 p-4 text-white">
                    <h2 className="text-xl font-semibold flex items-center gap-2">
                      <Database className="h-5 w-5" />
                      Dataset Uploader
                    </h2>
                    <p className="text-sm opacity-90">Import a CSV file with IIoT traffic data</p>
                  </div>
                  
                  <div className="p-5">
                    <FileUpload onDataLoaded={handleDatasetLoaded} />
                    
                    {uploadedDataset.length > 0 && (
                      <div className="mt-6 flex justify-center">
                        <Button
                          onClick={() => setIsDatasetModalOpen(true)}
                          className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
                          disabled={isBatchProcessing}
                        >
                          <Database className="mr-2 h-4 w-4" />
                          Open Dataset ({uploadedDataset.length} records)
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
                
                {/* Dataset information sheet */}
                <Sheet>
                  <SheetTrigger asChild>
                    <Button variant="link" size="sm" className="mt-2 w-full">
                      <FileUp className="h-3 w-3 mr-1" />
                      Dataset format information
                    </Button>
                  </SheetTrigger>
                  <SheetContent>
                    <SheetHeader>
                      <SheetTitle>CSV Dataset Format</SheetTitle>
                      <SheetDescription>
                        Required format for IIoT traffic datasets
                      </SheetDescription>
                    </SheetHeader>
                    <div className="mt-6 space-y-4">
                      <p className="text-sm">
                        The CSV file must include the following columns:
                      </p>
                      
                      <div className="overflow-x-auto">
                        <table className="w-full text-sm border-collapse">
                          <thead>
                            <tr className="bg-slate-100 dark:bg-slate-800">
                              <th className="border border-slate-200 dark:border-slate-700 p-2 text-left">Column</th>
                              <th className="border border-slate-200 dark:border-slate-700 p-2 text-left">Type</th>
                              <th className="border border-slate-200 dark:border-slate-700 p-2 text-left">Description</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td className="border border-slate-200 dark:border-slate-700 p-2 font-medium">packet_size</td>
                              <td className="border border-slate-200 dark:border-slate-700 p-2">Number</td>
                              <td className="border border-slate-200 dark:border-slate-700 p-2">Size in bytes (20-65535)</td>
                            </tr>
                            <tr>
                              <td className="border border-slate-200 dark:border-slate-700 p-2 font-medium">duration</td>
                              <td className="border border-slate-200 dark:border-slate-700 p-2">Number</td>
                              <td className="border border-slate-200 dark:border-slate-700 p-2">Connection time in seconds</td>
                            </tr>
                            <tr>
                              <td className="border border-slate-200 dark:border-slate-700 p-2 font-medium">protocol</td>
                              <td className="border border-slate-200 dark:border-slate-700 p-2">Number</td>
                              <td className="border border-slate-200 dark:border-slate-700 p-2">0=TCP, 1=UDP, 2=ICMP, 3=Other</td>
                            </tr>
                            <tr>
                              <td className="border border-slate-200 dark:border-slate-700 p-2 font-medium">src_bytes</td>
                              <td className="border border-slate-200 dark:border-slate-700 p-2">Number</td>
                              <td className="border border-slate-200 dark:border-slate-700 p-2">Bytes from source</td>
                            </tr>
                            <tr>
                              <td className="border border-slate-200 dark:border-slate-700 p-2 font-medium">dst_bytes</td>
                              <td className="border border-slate-200 dark:border-slate-700 p-2">Number</td>
                              <td className="border border-slate-200 dark:border-slate-700 p-2">Bytes to destination</td>
                            </tr>
                            <tr>
                              <td className="border border-slate-200 dark:border-slate-700 p-2 font-medium">flag</td>
                              <td className="border border-slate-200 dark:border-slate-700 p-2">Number</td>
                              <td className="border border-slate-200 dark:border-slate-700 p-2">0=Normal, 1=Error, 2=Critical</td>
                            </tr>
                            <tr>
                              <td className="border border-slate-200 dark:border-slate-700 p-2 font-medium">wrong_fragment</td>
                              <td className="border border-slate-200 dark:border-slate-700 p-2">Number</td>
                              <td className="border border-slate-200 dark:border-slate-700 p-2">0=No, 1=Yes</td>
                            </tr>
                            <tr>
                              <td className="border border-slate-200 dark:border-slate-700 p-2 font-medium">urgent</td>
                              <td className="border border-slate-200 dark:border-slate-700 p-2">Number</td>
                              <td className="border border-slate-200 dark:border-slate-700 p-2">0=No, 1=Yes</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                      
                      <div className="text-sm bg-slate-100 dark:bg-slate-800 p-3 rounded-md">
                        <p className="font-medium">Example CSV:</p>
                        <pre className="mt-2 text-xs overflow-x-auto whitespace-pre-wrap">
                          packet_size,duration,protocol,src_bytes,dst_bytes,flag,wrong_fragment,urgent<br/>
                          512,0.89,1,2000,1500,0,0,0<br/>
                          32,8.5,3,15000,250,2,1,1<br/>
                          1024,1.2,0,5000,3000,0,0,0
                        </pre>
                      </div>
                    </div>
                  </SheetContent>
                </Sheet>
                
              </TabsContent>
            </Tabs>
          </div>
          <div className="lg:col-span-2">
            <Dashboard 
              predictionResult={predictionResult} 
              logs={logs} 
              clearLogs={() => setLogs([])} 
              isBatchProcessing={isBatchProcessing}
            />
          </div>
        </div>
      </div>

      {/* Dataset Preview Modal */}
      <DatasetPreviewModal
        data={uploadedDataset}
        open={isDatasetModalOpen}
        onOpenChange={setIsDatasetModalOpen}
        onAnalyze={handleBatchAnalyze}
      />
    </div>
  );
};

export default Index;
