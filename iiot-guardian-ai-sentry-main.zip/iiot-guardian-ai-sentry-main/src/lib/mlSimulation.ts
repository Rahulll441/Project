
import { TrafficData } from "@/types/traffic";

// Define feature importance based on a hypothetical Random Forest model
const featureImportance = {
  packet_size: 0.15,
  duration: 0.18,
  protocol: 0.12,
  src_bytes: 0.22,
  dst_bytes: 0.19,
  flag: 0.05,
  wrong_fragment: 0.06,
  urgent: 0.03
};

// Define normal ranges for each feature
const normalRanges = {
  packet_size: { min: 60, max: 1500, weight: 1 },
  duration: { min: 0, max: 3, weight: 1.2 },
  protocol: { min: 0, max: 3, weight: 0.8 }, // Categorical: 0-TCP, 1-UDP, 2-ICMP, 3-OTHER
  src_bytes: { min: 0, max: 8000, weight: 1.5 },
  dst_bytes: { min: 0, max: 5000, weight: 1.2 },
  flag: { min: 0, max: 2, weight: 0.7 }, // Categorical: 0-Normal, 1-Error, 2-Critical
  wrong_fragment: { min: 0, max: 1, weight: 2 }, // 0 or 1
  urgent: { min: 0, max: 1, weight: 2.5 } // 0 or 1
};

// Calculate anomaly score based on deviation from normal range
const calculateAnomalyScore = (value: number, feature: keyof TrafficData): number => {
  const range = normalRanges[feature];
  
  // For categorical features, score abnormality based on specific values
  if (feature === 'protocol') {
    return value > 2 ? range.weight : 0; // Higher protocols are less common
  }
  
  if (feature === 'flag') {
    return value > 1 ? range.weight : 0; // Error and critical flags are suspicious
  }
  
  if (feature === 'wrong_fragment' || feature === 'urgent') {
    return value === 1 ? range.weight : 0; // Any presence is suspicious
  }
  
  // For numerical features, calculate deviation
  if (value < range.min || value > range.max) {
    const deviation = Math.min(
      Math.abs(value - range.min), 
      Math.abs(value - range.max)
    ) / (range.max - range.min);
    return deviation * range.weight;
  }
  
  return 0;
};

// Simulate ML model prediction
export const simulatePrediction = (data: TrafficData): { prediction: number; confidence: number; timestamp: Date } => {
  let anomalyScore = 0;
  let totalWeight = 0;
  
  // Calculate weighted anomaly score across all features
  for (const [feature, importance] of Object.entries(featureImportance) as [keyof TrafficData, number][]) {
    const featureScore = calculateAnomalyScore(data[feature], feature);
    anomalyScore += featureScore * importance;
    totalWeight += importance;
  }
  
  // Normalize anomaly score (0-1)
  const normalizedScore = anomalyScore / totalWeight;
  
  // Add some randomness to make predictions less deterministic
  const randomFactor = Math.random() * 0.1 - 0.05; // -0.05 to +0.05
  const finalScore = Math.max(0, Math.min(1, normalizedScore + randomFactor));
  
  // Classification threshold
  const threshold = 0.65;
  const prediction = finalScore > threshold ? 1 : 0;
  
  // Calculate confidence (higher deviation from threshold = higher confidence)
  const distanceFromThreshold = Math.abs(finalScore - threshold);
  const confidence = 0.5 + distanceFromThreshold;
  
  return {
    prediction,
    confidence: Math.min(0.99, confidence), // Cap at 99% confidence
    timestamp: new Date()
  };
};
