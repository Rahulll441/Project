import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Upload, FileText, Check, X, ExternalLink } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { TrafficData } from "@/types/traffic";
import Papa from "papaparse";

type FileUploadProps = {
  onDataLoaded: (data: TrafficData[]) => void;
};

const FileUpload = ({ onDataLoaded }: FileUploadProps) => {
  const [isDragging, setIsDragging] = useState(false);
  const [fileName, setFileName] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    
    if (e.dataTransfer.files.length) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.length) {
      processFile(e.target.files[0]);
    }
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  const processFile = (file: File) => {
    setIsLoading(true);
    setFileName(file.name);

    if (file.type !== "text/csv" && !file.name.endsWith('.csv')) {
      toast({
        title: "Invalid file format",
        description: "Please upload a CSV file",
        variant: "destructive",
      });
      setFileName(null);
      setIsLoading(false);
      return;
    }

    Papa.parse(file, {
      header: true,
      dynamicTyping: true,
      complete: (results) => {
        if (results.errors.length > 0) {
          toast({
            title: "Error parsing file",
            description: results.errors[0].message,
            variant: "destructive",
          });
          setFileName(null);
          setIsLoading(false);
          return;
        }

        try {
          // Process and validate the parsed data
          const trafficData: TrafficData[] = results.data.map((row: any) => {
            // Check if all required fields exist
            const requiredFields = [
              "packet_size", "duration", "protocol", 
              "src_bytes", "dst_bytes", "flag", 
              "wrong_fragment", "urgent"
            ];
            
            for (const field of requiredFields) {
              if (row[field] === undefined) {
                throw new Error(`Missing field: ${field}`);
              }
            }

            // Convert to TrafficData format
            return {
              packet_size: Number(row.packet_size),
              duration: Number(row.duration),
              protocol: Number(row.protocol),
              src_bytes: Number(row.src_bytes),
              dst_bytes: Number(row.dst_bytes),
              flag: Number(row.flag),
              wrong_fragment: Number(row.wrong_fragment),
              urgent: Number(row.urgent),
            };
          });

          // Check if we have valid data
          if (trafficData.length === 0) {
            throw new Error("No valid data found in the file");
          }

          // Pass the data up to the parent component
          onDataLoaded(trafficData);
          
          toast({
            title: "Data loaded successfully",
            description: `Loaded ${trafficData.length} records`,
            variant: "default",
          });
        } catch (error) {
          toast({
            title: "Invalid data format",
            description: error instanceof Error ? error.message : "The CSV format doesn't match required fields",
            variant: "destructive",
          });
          setFileName(null);
        }
        setIsLoading(false);
      },
      error: (error) => {
        toast({
          title: "Error parsing file",
          description: error.message,
          variant: "destructive",
        });
        setFileName(null);
        setIsLoading(false);
      }
    });
  };

  return (
    <div className="w-full">
      <div
        className={`border-2 border-dashed rounded-lg p-6 transition-all duration-200 text-center ${
          isDragging
            ? "border-blue-500 bg-blue-50 dark:bg-blue-950/30"
            : "border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800/50"
        }`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={triggerFileInput}
      >
        <input
          type="file"
          className="hidden"
          ref={fileInputRef}
          onChange={handleFileInputChange}
          accept=".csv"
        />
        
        {fileName ? (
          <div className="flex items-center justify-center gap-2">
            <FileText className="h-8 w-8 text-blue-500" />
            <div className="text-left">
              <p className="font-medium text-slate-900 dark:text-slate-100">
                {fileName}
              </p>
              {isLoading ? (
                <p className="text-xs text-slate-500 dark:text-slate-400 animate-pulse">
                  Processing...
                </p>
              ) : (
                <p className="text-xs text-green-500 dark:text-green-400 flex items-center">
                  <Check className="h-3 w-3 mr-1" /> Ready
                </p>
              )}
            </div>
            {!isLoading && (
              <Button
                variant="outline"
                size="icon"
                className="h-6 w-6 ml-2"
                onClick={(e) => {
                  e.stopPropagation();
                  setFileName(null);
                }}
              >
                <X className="h-3 w-3" />
              </Button>
            )}
          </div>
        ) : (
          <div className="space-y-2">
            <Upload className="h-10 w-10 text-slate-400 mx-auto" />
            <div>
              <p className="font-medium text-slate-700 dark:text-slate-300">
                Drop your CSV file here or click to browse
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Upload a CSV file containing IIoT traffic data
              </p>
            </div>
          </div>
        )}
      </div>

      <div className="mt-3 text-xs text-slate-500 dark:text-slate-400">
        <p className="flex items-center justify-center gap-1">
          <span>CSV must include required columns:</span>
          <ExternalLink className="h-3 w-3" />
          <Button variant="link" size="sm" className="h-4 p-0 text-xs" asChild>
            <a href="#" onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              toast({
                title: "Required CSV Format",
                description: "packet_size, duration, protocol, src_bytes, dst_bytes, flag, wrong_fragment, urgent",
              });
            }}>
              See format
            </a>
          </Button>
        </p>
      </div>
    </div>
  );
};

export default FileUpload;
