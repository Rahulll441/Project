
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { TrafficData } from "@/types/traffic";
import { useState } from "react";
import { Database, ArrowRight, AlertCircle } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

type DatasetPreviewModalProps = {
  data: TrafficData[];
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onAnalyze: (data: TrafficData[]) => void;
};

const DatasetPreviewModal = ({
  data,
  open,
  onOpenChange,
  onAnalyze,
}: DatasetPreviewModalProps) => {
  const [selectedRecords, setSelectedRecords] = useState<TrafficData[]>([]);
  const [selectedTab, setSelectedTab] = useState<string>("preview");
  
  // Select all records by default when modal opens
  useState(() => {
    if (open && data.length > 0) {
      setSelectedRecords(data);
    }
  });

  const handleAnalyze = () => {
    onAnalyze(selectedRecords.length > 0 ? selectedRecords : data);
    onOpenChange(false);
  };

  // Calculate some basic statistics
  const statsNormal = {
    count: data.filter(d => d.flag === 0).length,
    avgPacketSize: data.filter(d => d.flag === 0).reduce((sum, d) => sum + d.packet_size, 0) / 
                  (data.filter(d => d.flag === 0).length || 1),
    avgSrcBytes: data.filter(d => d.flag === 0).reduce((sum, d) => sum + d.src_bytes, 0) / 
                (data.filter(d => d.flag === 0).length || 1)
  };
  
  const statsSuspicious = {
    count: data.filter(d => d.flag !== 0).length,
    avgPacketSize: data.filter(d => d.flag !== 0).reduce((sum, d) => sum + d.packet_size, 0) / 
                  (data.filter(d => d.flag !== 0).length || 1),
    avgSrcBytes: data.filter(d => d.flag !== 0).reduce((sum, d) => sum + d.src_bytes, 0) / 
                (data.filter(d => d.flag !== 0).length || 1)
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-4xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Database className="h-5 w-5 text-blue-500" />
            Dataset Preview
            <span className="text-slate-500 font-normal text-sm ml-2">
              ({data.length} records)
            </span>
          </DialogTitle>
          <DialogDescription>
            Review your dataset before running the intrusion detection analysis
          </DialogDescription>
        </DialogHeader>

        <Tabs value={selectedTab} onValueChange={setSelectedTab}>
          <TabsList className="mb-4">
            <TabsTrigger value="preview">Data Preview</TabsTrigger>
            <TabsTrigger value="stats">Statistics</TabsTrigger>
            <TabsTrigger value="info">Info</TabsTrigger>
          </TabsList>
          
          <TabsContent value="preview" className="mt-2">
            <div className="overflow-auto max-h-[400px] rounded-md border border-slate-200 dark:border-slate-700">
              <table className="w-full text-sm">
                <thead className="bg-slate-100 dark:bg-slate-800 sticky top-0">
                  <tr>
                    <th className="p-2 text-left font-medium text-slate-500 dark:text-slate-400">Packet Size</th>
                    <th className="p-2 text-left font-medium text-slate-500 dark:text-slate-400">Duration</th>
                    <th className="p-2 text-left font-medium text-slate-500 dark:text-slate-400">Protocol</th>
                    <th className="p-2 text-left font-medium text-slate-500 dark:text-slate-400">Src Bytes</th>
                    <th className="p-2 text-left font-medium text-slate-500 dark:text-slate-400">Dst Bytes</th>
                    <th className="p-2 text-left font-medium text-slate-500 dark:text-slate-400">Flag</th>
                    <th className="p-2 text-left font-medium text-slate-500 dark:text-slate-400">Wrong Frag.</th>
                    <th className="p-2 text-left font-medium text-slate-500 dark:text-slate-400">Urgent</th>
                  </tr>
                </thead>
                <tbody>
                  {data.slice(0, 50).map((row, index) => (
                    <tr 
                      key={index}
                      className={`
                        border-b border-slate-200 dark:border-slate-700 
                        ${row.flag !== 0 ? 'bg-red-50 dark:bg-red-950/20' : ''}
                        hover:bg-slate-50 dark:hover:bg-slate-800/50
                      `}
                    >
                      <td className="p-2">{row.packet_size}</td>
                      <td className="p-2">{row.duration}</td>
                      <td className="p-2">
                        {row.protocol === 0 ? 'TCP' :
                         row.protocol === 1 ? 'UDP' :
                         row.protocol === 2 ? 'ICMP' : 'Other'}
                      </td>
                      <td className="p-2">{row.src_bytes}</td>
                      <td className="p-2">{row.dst_bytes}</td>
                      <td className="p-2">
                        <span className={`
                          px-1.5 py-0.5 rounded-full text-xs font-medium
                          ${row.flag === 0 ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' : 
                            row.flag === 1 ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400' :
                            'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400'}
                        `}>
                          {row.flag === 0 ? 'Normal' : 
                           row.flag === 1 ? 'Error' : 'Critical'}
                        </span>
                      </td>
                      <td className="p-2">{row.wrong_fragment}</td>
                      <td className="p-2">{row.urgent}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {data.length > 50 && (
                <div className="p-2 text-center text-sm text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-200 dark:border-slate-700">
                  Showing 50 of {data.length} records
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="stats">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50">
                <h3 className="font-medium mb-2 text-green-700 dark:text-green-400 flex items-center gap-1">
                  <div className="w-3 h-3 rounded-full bg-green-500"></div>
                  Normal Traffic
                </h3>
                <ul className="space-y-1">
                  <li className="flex justify-between">
                    <span className="text-slate-500 dark:text-slate-400">Records:</span>
                    <span className="font-medium">{statsNormal.count}</span>
                  </li>
                  <li className="flex justify-between">
                    <span className="text-slate-500 dark:text-slate-400">Avg. Packet Size:</span>
                    <span className="font-medium">{statsNormal.avgPacketSize.toFixed(2)} bytes</span>
                  </li>
                  <li className="flex justify-between">
                    <span className="text-slate-500 dark:text-slate-400">Avg. Source Bytes:</span>
                    <span className="font-medium">{statsNormal.avgSrcBytes.toFixed(2)} bytes</span>
                  </li>
                </ul>
              </div>
              
              <div className="p-4 rounded-lg border border-slate-200 dark:border-slate-700 bg-red-50 dark:bg-red-950/20">
                <h3 className="font-medium mb-2 text-red-700 dark:text-red-400 flex items-center gap-1">
                  <div className="w-3 h-3 rounded-full bg-red-500"></div>
                  Suspicious Traffic
                </h3>
                <ul className="space-y-1">
                  <li className="flex justify-between">
                    <span className="text-slate-500 dark:text-slate-400">Records:</span>
                    <span className="font-medium">{statsSuspicious.count}</span>
                  </li>
                  <li className="flex justify-between">
                    <span className="text-slate-500 dark:text-slate-400">Avg. Packet Size:</span>
                    <span className="font-medium">{statsSuspicious.avgPacketSize.toFixed(2)} bytes</span>
                  </li>
                  <li className="flex justify-between">
                    <span className="text-slate-500 dark:text-slate-400">Avg. Source Bytes:</span>
                    <span className="font-medium">{statsSuspicious.avgSrcBytes.toFixed(2)} bytes</span>
                  </li>
                </ul>
              </div>
            </div>

            <div className="mt-4 p-4 rounded-lg border border-slate-200 dark:border-slate-700 bg-blue-50 dark:bg-blue-950/20">
              <h3 className="font-medium mb-2 text-blue-700 dark:text-blue-400">Dataset Composition</h3>
              <div className="flex h-6 w-full rounded-full overflow-hidden">
                <div 
                  className="bg-green-500 h-full" 
                  style={{ width: `${(statsNormal.count / data.length) * 100}%` }}
                ></div>
                <div 
                  className="bg-red-500 h-full" 
                  style={{ width: `${(statsSuspicious.count / data.length) * 100}%` }}
                ></div>
              </div>
              <div className="flex justify-between text-xs mt-1">
                <div className="text-green-700 dark:text-green-400">
                  Normal: {((statsNormal.count / data.length) * 100).toFixed(1)}%
                </div>
                <div className="text-red-700 dark:text-red-400">
                  Suspicious: {((statsSuspicious.count / data.length) * 100).toFixed(1)}%
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="info">
            <div className="space-y-4">
              <div className="flex items-start gap-2 p-4 rounded-lg border border-amber-200 bg-amber-50 dark:border-amber-900/50 dark:bg-amber-950/20">
                <AlertCircle className="h-5 w-5 text-amber-500 mt-0.5" />
                <div>
                  <h3 className="font-medium text-amber-800 dark:text-amber-400">About This Dataset</h3>
                  <p className="text-sm text-amber-700 dark:text-amber-300">
                    This preview shows your uploaded IIoT traffic data. The ML model will analyze this data
                    to detect potential intrusions based on various traffic metrics.
                  </p>
                </div>
              </div>

              <div>
                <h3 className="font-medium mb-2">Field Descriptions:</h3>
                <ul className="space-y-2 text-sm">
                  <li>
                    <span className="font-medium">Packet Size:</span> Size of network packets in bytes (typical range: 60-1500)
                  </li>
                  <li>
                    <span className="font-medium">Duration:</span> Connection duration in seconds
                  </li>
                  <li>
                    <span className="font-medium">Protocol:</span> Network protocol (0=TCP, 1=UDP, 2=ICMP, 3=Other)
                  </li>
                  <li>
                    <span className="font-medium">Src/Dst Bytes:</span> Bytes transferred from source/to destination
                  </li>
                  <li>
                    <span className="font-medium">Flag:</span> Connection status flag (0=Normal, 1=Error, 2=Critical)
                  </li>
                  <li>
                    <span className="font-medium">Wrong Fragment:</span> Indicates fragmentation error (0=No, 1=Yes)
                  </li>
                  <li>
                    <span className="font-medium">Urgent:</span> Contains urgent packets (0=No, 1=Yes)
                  </li>
                </ul>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleAnalyze} className="gap-1 bg-blue-600 hover:bg-blue-700">
            Analyze Dataset <ArrowRight className="h-4 w-4" />
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default DatasetPreviewModal;
