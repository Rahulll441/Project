import { useState, useEffect } from "react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  Legend,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
} from "recharts";
import { 
  ShieldAlert, 
  ShieldCheck, 
  Clock, 
  Trash2,
  BarChart3,
  PieChartIcon,
  NetworkIcon,
  AlertTriangle,
  ArrowUpRight,
  Activity,
  Zap,
  List,
  LineChart as LineChartIcon
} from "lucide-react";
import { LogEntry } from "@/types/logs";
import { formatDistanceToNow } from "date-fns";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Progress } from "@/components/ui/progress";

interface DashboardProps {
  predictionResult: {
    prediction: number;
    confidence: number;
    timestamp: Date;
  } | null;
  logs: LogEntry[];
  clearLogs: () => void;
  isBatchProcessing?: boolean;
}

const Dashboard = ({ predictionResult, logs, clearLogs, isBatchProcessing = false }: DashboardProps) => {
  const [activeTab, setActiveTab] = useState("overview");
  const [timelineData, setTimelineData] = useState<any[]>([]);
  const [animate, setAnimate] = useState(false);
  
  // Calculate statistics
  const totalAnalyzed = logs.length;
  const intrusionsCount = logs.filter(log => log.result === 1).length;
  const normalCount = logs.filter(log => log.result === 0).length;
  const intrusionRate = totalAnalyzed > 0 ? (intrusionsCount / totalAnalyzed) * 100 : 0;

  // Prepare chart data
  const pieData = [
    { name: "Normal Traffic", value: normalCount, color: "#10b981" },
    { name: "Intrusions", value: intrusionsCount, color: "#ef4444" }
  ];

  const featureData = predictionResult ? [
    { name: "Packet Size", value: predictionResult.confidence * 100 * 0.15 },
    { name: "Duration", value: predictionResult.confidence * 100 * 0.18 },
    { name: "Protocol", value: predictionResult.confidence * 100 * 0.12 },
    { name: "Src Bytes", value: predictionResult.confidence * 100 * 0.22 },
    { name: "Dst Bytes", value: predictionResult.confidence * 100 * 0.19 },
    { name: "Flag", value: predictionResult.confidence * 100 * 0.05 },
    { name: "Wrong Frag", value: predictionResult.confidence * 100 * 0.06 },
    { name: "Urgent", value: predictionResult.confidence * 100 * 0.03 }
  ] : [];

  // Convert logs to timeline data
  useEffect(() => {
    if (logs.length > 0) {
      const newData = logs.slice(0, 10).map((log, index) => ({
        name: `Analysis ${index + 1}`,
        result: log.result,
        confidence: log.confidence * 100,
        timestamp: log.timestamp.getTime(),
      })).reverse();
      
      setTimelineData(newData);
      
      // Trigger animation
      setAnimate(true);
      setTimeout(() => setAnimate(false), 1000);
    }
  }, [logs]);

  // Get the latest event for real-time notification
  const latestEvent = logs[0];

  return (
    <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab} className="space-y-4">
      <div className="flex justify-between items-center">
        <TabsList className="bg-slate-100 dark:bg-slate-800">
          <TabsTrigger value="overview" className="flex items-center gap-1 data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700 dark:data-[state=active]:bg-blue-900 dark:data-[state=active]:text-blue-200">
            <Activity className="h-4 w-4" />
            <span>Overview</span>
          </TabsTrigger>
          <TabsTrigger value="analysis" className="flex items-center gap-1 data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700 dark:data-[state=active]:bg-blue-900 dark:data-[state=active]:text-blue-200">
            <BarChart3 className="h-4 w-4" />
            <span>Analysis</span>
          </TabsTrigger>
          <TabsTrigger value="logs" className="flex items-center gap-1 data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700 dark:data-[state=active]:bg-blue-900 dark:data-[state=active]:text-blue-200">
            <List className="h-4 w-4" />
            <span>Logs</span>
          </TabsTrigger>
        </TabsList>
        
        {logs.length > 0 && (
          <Button 
            variant="outline" 
            size="sm" 
            onClick={clearLogs}
            className="border-red-200 text-red-600 hover:bg-red-50 dark:border-red-800 dark:text-red-400 dark:hover:bg-red-900/30"
          >
            <Trash2 className="mr-2 h-4 w-4" />
            Clear Data
          </Button>
        )}
      </div>

      {/* Display a notification for the latest event if it exists */}
      {latestEvent && (
        <div className={`rounded-lg border p-3 ${animate ? 'animate-fade-in-scale' : ''} ${
          latestEvent.result === 1 
            ? 'bg-red-50 border-red-200 dark:bg-red-900/30 dark:border-red-800' 
            : 'bg-green-50 border-green-200 dark:bg-green-900/30 dark:border-green-800'
        }`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {latestEvent.result === 1 ? (
                <>
                  <ShieldAlert className="h-5 w-5 text-red-500" />
                  <span className="font-semibold text-red-700 dark:text-red-300">Intrusion Detected</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="h-5 w-5 text-green-500" />
                  <span className="font-semibold text-green-700 dark:text-green-300">Normal Traffic</span>
                </>
              )}
              <Badge className={latestEvent.result === 1 ? 'bg-red-200 text-red-800 hover:bg-red-300 dark:bg-red-900 dark:text-red-300 dark:hover:bg-red-800' : 'bg-green-200 text-green-800 hover:bg-green-300 dark:bg-green-900 dark:text-green-300 dark:hover:bg-green-800'}>
                {(latestEvent.confidence * 100).toFixed(1)}% confidence
              </Badge>
            </div>
            <span className="text-xs text-slate-500 dark:text-slate-400">
              {formatDistanceToNow(latestEvent.timestamp, { addSuffix: true })}
            </span>
          </div>
        </div>
      )}

      <TabsContent value="overview" className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card className="border-slate-200 dark:border-slate-700 shadow-sm hover:shadow-md transition-shadow duration-200">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-blue-700 dark:text-blue-400">
                <NetworkIcon className="h-5 w-5" />
                IIoT Traffic Status
              </CardTitle>
              <CardDescription>Current network traffic classification</CardDescription>
            </CardHeader>
            <CardContent>
              {predictionResult ? (
                <div className="flex flex-col items-center py-6">
                  {predictionResult.prediction === 0 ? (
                    <div className="animate-fade-in-up">
                      <div className="p-4 bg-green-50 rounded-full mb-4 shadow-sm dark:bg-green-900/30">
                        <ShieldCheck className="h-16 w-16 text-green-500" />
                      </div>
                      <h3 className="text-2xl font-bold text-green-600 dark:text-green-400">Normal Traffic</h3>
                      <div className="mt-4 w-full max-w-xs">
                        <div className="flex justify-between mb-1 text-sm">
                          <span>Confidence Level</span>
                          <span>{(predictionResult.confidence * 100).toFixed(2)}%</span>
                        </div>
                        <Progress value={predictionResult.confidence * 100} className="h-2 bg-green-100 dark:bg-green-900">
                          <div className="h-full bg-green-500 rounded-full" />
                        </Progress>
                      </div>
                    </div>
                  ) : (
                    <div className="animate-pulse">
                      <div className="p-4 bg-red-50 rounded-full mb-4 shadow-sm dark:bg-red-900/30">
                        <ShieldAlert className="h-16 w-16 text-red-500" />
                      </div>
                      <h3 className="text-2xl font-bold text-red-600 dark:text-red-400">Intrusion Detected!</h3>
                      <div className="mt-4 w-full max-w-xs">
                        <div className="flex justify-between mb-1 text-sm">
                          <span>Threat Level</span>
                          <span>{(predictionResult.confidence * 100).toFixed(2)}%</span>
                        </div>
                        <Progress value={predictionResult.confidence * 100} className="h-2 bg-red-100 dark:bg-red-900">
                          <div className="h-full bg-red-500 rounded-full" />
                        </Progress>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="flex flex-col items-center py-10 text-gray-400">
                  <AlertTriangle className="h-16 w-16 mb-2 text-slate-300 dark:text-slate-600" />
                  <p>No traffic analyzed yet</p>
                  <p className="text-sm mt-2">Submit traffic data to see results</p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="border-slate-200 dark:border-slate-700 shadow-sm hover:shadow-md transition-shadow duration-200">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-blue-700 dark:text-blue-400">
                <PieChartIcon className="h-5 w-5" />
                Traffic Distribution
              </CardTitle>
              <CardDescription>Breakdown of analyzed traffic</CardDescription>
            </CardHeader>
            <CardContent>
              {totalAnalyzed > 0 ? (
                <div className="h-[180px] mt-2">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={pieData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="value"
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        labelLine={false}
                      >
                        {pieData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => [`${value} packets`, ""]} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              ) : (
                <div className="flex flex-col items-center py-10 text-gray-400">
                  <PieChartIcon className="h-16 w-16 mb-2 text-slate-300 dark:text-slate-600" />
                  <p>No data to display</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="border-slate-200 dark:border-slate-700 shadow-sm hover:shadow-md transition-all duration-200 hover:scale-[1.02]">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-blue-700 dark:text-blue-400">
                <BarChart3 className="h-5 w-5" />
                Total Analyzed
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{totalAnalyzed}</div>
              <p className="text-sm text-gray-500">traffic packets</p>
              {totalAnalyzed > 0 && (
                <div className="flex items-center mt-2 text-green-600 dark:text-green-400">
                  <ArrowUpRight className="h-4 w-4 mr-1" />
                  <span className="text-xs">
                    Analyzed {logs.length > 1 ? "recently" : "just now"}
                  </span>
                </div>
              )}
            </CardContent>
          </Card>
          
          <Card className="border-slate-200 dark:border-slate-700 shadow-sm hover:shadow-md transition-all duration-200 hover:scale-[1.02]">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-blue-700 dark:text-blue-400">
                <Activity className="h-5 w-5" />
                Intrusion Rate
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{intrusionRate.toFixed(1)}%</div>
              <p className="text-sm text-gray-500">of total traffic</p>
              <div className="mt-2">
                <Progress value={intrusionRate} className="h-2">
                  <div 
                    className={`h-full rounded-full ${
                      intrusionRate > 50 
                        ? 'bg-red-500' 
                        : intrusionRate > 25 
                          ? 'bg-yellow-500' 
                          : 'bg-green-500'
                    }`} 
                  />
                </Progress>
              </div>
            </CardContent>
          </Card>
          
          <Card className="border-slate-200 dark:border-slate-700 shadow-sm hover:shadow-md transition-all duration-200 hover:scale-[1.02]">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-blue-700 dark:text-blue-400">
                <AlertTriangle className="h-5 w-5" />
                Intrusions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{intrusionsCount}</div>
              <p className="text-sm text-gray-500">detected</p>
              <div className="mt-2 flex items-center">
                <Badge className={
                  intrusionsCount > 5 
                    ? "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300" 
                    : intrusionsCount > 0 
                      ? "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300" 
                      : "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
                }>
                  {intrusionsCount === 0 
                    ? "Secure Network" 
                    : intrusionsCount > 5 
                      ? "High Alert" 
                      : "Moderate Alert"}
                </Badge>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Add a new timeline chart for the overview */}
        {timelineData.length > 0 && (
          <Card className="border-slate-200 dark:border-slate-700 shadow-sm hover:shadow-md transition-shadow duration-200">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-blue-700 dark:text-blue-400">
                <LineChartIcon className="h-5 w-5" />
                Traffic Analysis Timeline
              </CardTitle>
              <CardDescription>Recent traffic analysis history</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[200px] mt-2">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={timelineData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#ddd" />
                    <XAxis dataKey="name" />
                    <YAxis domain={[0, 100]} />
                    <Tooltip 
                      formatter={(value, name) => {
                        if (name === 'confidence') return [`${Number(value).toFixed(1)}%`, 'Confidence'];
                        return [value, name];
                      }}
                    />
                    <Legend />
                    <Line 
                      type="monotone" 
                      dataKey="confidence" 
                      stroke="#3b82f6" 
                      strokeWidth={2}
                      dot={{ 
                        stroke: '#000',
                        fill: '#10b981', // Default to green color
                        r: 5,
                        // Use a custom renderer to dynamically set the fill color
                        fillOpacity: 1,
                        strokeOpacity: 1
                      }}
                      activeDot={{ r: 8 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        )}
      </TabsContent>

      <TabsContent value="analysis" className="space-y-4">
        <Card className="border-slate-200 dark:border-slate-700 shadow-sm hover:shadow-md transition-shadow duration-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-blue-700 dark:text-blue-400">
              <BarChart3 className="h-5 w-5" />
              Feature Importance Analysis
            </CardTitle>
            <CardDescription>Contribution of each feature to the prediction</CardDescription>
          </CardHeader>
          <CardContent>
            {predictionResult ? (
              <div className="h-[300px] mt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    layout="vertical"
                    data={featureData}
                    margin={{
                      top: 5,
                      right: 30,
                      left: 120,
                      bottom: 5,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} />
                    <XAxis type="number" domain={[0, 'dataMax']} />
                    <YAxis type="category" dataKey="name" width={110} />
                    <Tooltip formatter={(value) => [`${parseFloat(value as string).toFixed(2)}%`, "Contribution"]} />
                    <Legend />
                    <Bar 
                      dataKey="value" 
                      fill={predictionResult.prediction === 0 ? "#10b981" : "#ef4444"} 
                      name="Contribution %" 
                      radius={[0, 4, 4, 0]}
                      animationDuration={2000}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="flex flex-col items-center py-10 text-gray-400">
                <BarChart3 className="h-16 w-16 mb-2 text-slate-300 dark:text-slate-600" />
                <p>No analysis data available</p>
                <p className="text-sm mt-2">Analyze traffic to see feature breakdown</p>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="border-slate-200 dark:border-slate-700 shadow-sm hover:shadow-md transition-shadow duration-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-blue-700 dark:text-blue-400">
              <Zap className="h-5 w-5" />
              Last Prediction Details
            </CardTitle>
            <CardDescription>
              {predictionResult ? (
                <span className="flex items-center">
                  <Clock className="h-4 w-4 mr-1" /> 
                  {formatDistanceToNow(predictionResult.timestamp, { addSuffix: true })}
                </span>
              ) : (
                "No prediction data available"
              )}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {predictionResult ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm hover:shadow-md transition-all duration-200 hover:scale-[1.02]">
                  <h4 className="text-sm font-medium text-slate-500 dark:text-slate-400">Prediction</h4>
                  <p className={`text-lg font-bold ${predictionResult.prediction === 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                    {predictionResult.prediction === 0 ? "Normal" : "Intrusion"}
                  </p>
                </div>
                <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm hover:shadow-md transition-all duration-200 hover:scale-[1.02]">
                  <h4 className="text-sm font-medium text-slate-500 dark:text-slate-400">Confidence</h4>
                  <p className="text-lg font-bold text-blue-600 dark:text-blue-400">
                    {(predictionResult.confidence * 100).toFixed(2)}%
                  </p>
                </div>
                <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm hover:shadow-md transition-all duration-200 hover:scale-[1.02]">
                  <h4 className="text-sm font-medium text-slate-500 dark:text-slate-400">Model Type</h4>
                  <p className="text-lg font-bold text-indigo-600 dark:text-indigo-400">Random Forest</p>
                </div>
                <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm hover:shadow-md transition-all duration-200 hover:scale-[1.02]">
                  <h4 className="text-sm font-medium text-slate-500 dark:text-slate-400">Response Time</h4>
                  <p className="text-lg font-bold text-amber-600 dark:text-amber-400">1.5s</p>
                </div>
              </div>
            ) : (
              <div className="flex justify-center py-6">
                <p className="text-slate-500 dark:text-slate-400">Submit traffic data to see prediction details</p>
              </div>
            )}
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="logs">
        <Card className="border-slate-200 dark:border-slate-700 shadow-sm hover:shadow-md transition-shadow duration-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-blue-700 dark:text-blue-400">
              <List className="h-5 w-5" />
              Traffic Analysis Logs
            </CardTitle>
            <CardDescription>History of analyzed network traffic</CardDescription>
          </CardHeader>
          <CardContent>
            {logs.length > 0 ? (
              <ScrollArea className="h-[500px] rounded-md pr-4">
                <div className="space-y-4">
                  {logs.map((log) => (
                    <div 
                      key={log.id} 
                      className={`border rounded-lg p-4 shadow-sm transition-all duration-200 hover:shadow-md ${
                        log.result === 0 
                          ? 'bg-green-50 border-green-200 dark:bg-green-900/20 dark:border-green-800' 
                          : 'bg-red-50 border-red-200 dark:bg-red-900/20 dark:border-red-800'
                      }`}
                    >
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex items-center gap-2">
                          {log.result === 0 ? (
                            <Badge variant="outline" className="bg-green-100 text-green-700 border-green-200 dark:bg-green-900 dark:text-green-300 dark:border-green-800">
                              <ShieldCheck className="h-3 w-3 mr-1" />
                              Normal
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="bg-red-100 text-red-700 border-red-200 dark:bg-red-900 dark:text-red-300 dark:border-red-800">
                              <ShieldAlert className="h-3 w-3 mr-1" />
                              Intrusion
                            </Badge>
                          )}
                          <span className="text-sm text-slate-700 dark:text-slate-300">
                            Confidence: {(log.confidence * 100).toFixed(2)}%
                          </span>
                        </div>
                        <span className="text-xs text-slate-500 dark:text-slate-400">
                          {formatDistanceToNow(log.timestamp, { addSuffix: true })}
                        </span>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs mt-3 bg-white dark:bg-slate-800 p-3 rounded border border-slate-200 dark:border-slate-700">
                        <div>
                          <span className="font-medium text-slate-500 dark:text-slate-400">Packet Size:</span> 
                          <span className="ml-1 font-medium text-slate-900 dark:text-slate-100">{log.data.packet_size}</span>
                        </div>
                        <div>
                          <span className="font-medium text-slate-500 dark:text-slate-400">Duration:</span> 
                          <span className="ml-1 font-medium text-slate-900 dark:text-slate-100">{log.data.duration}</span>
                        </div>
                        <div>
                          <span className="font-medium text-slate-500 dark:text-slate-400">Protocol:</span> 
                          <span className="ml-1 font-medium text-slate-900 dark:text-slate-100">{["TCP", "UDP", "ICMP", "Other"][log.data.protocol]}</span>
                        </div>
                        <div>
                          <span className="font-medium text-slate-500 dark:text-slate-400">Flag:</span> 
                          <span className="ml-1 font-medium text-slate-900 dark:text-slate-100">{["Normal", "Error", "Critical"][log.data.flag]}</span>
                        </div>
                        <div>
                          <span className="font-medium text-slate-500 dark:text-slate-400">Src Bytes:</span> 
                          <span className="ml-1 font-medium text-slate-900 dark:text-slate-100">{log.data.src_bytes}</span>
                        </div>
                        <div>
                          <span className="font-medium text-slate-500 dark:text-slate-400">Dst Bytes:</span> 
                          <span className="ml-1 font-medium text-slate-900 dark:text-slate-100">{log.data.dst_bytes}</span>
                        </div>
                        <div>
                          <span className="font-medium text-slate-500 dark:text-slate-400">Wrong Frag:</span> 
                          <span className="ml-1 font-medium text-slate-900 dark:text-slate-100">{log.data.wrong_fragment ? "Yes" : "No"}</span>
                        </div>
                        <div>
                          <span className="font-medium text-slate-500 dark:text-slate-400">Urgent:</span> 
                          <span className="ml-1 font-medium text-slate-900 dark:text-slate-100">{log.data.urgent ? "Yes" : "No"}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            ) : (
              <div className="flex flex-col items-center py-12 text-gray-400">
                <AlertTriangle className="h-16 w-16 mb-4 text-slate-300 dark:text-slate-600" />
                <p>No logs available</p>
                <p className="text-sm mt-2">Analyze traffic to generate logs</p>
              </div>
            )}
          </CardContent>
        </Card>
      </TabsContent>
    </Tabs>
  );
};

export default Dashboard;
