
import { useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { TrafficData } from "@/types/traffic";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { InfoIcon, Zap, Database, Shuffle, NetworkIcon, BadgeAlert } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

// Form validation schema
const formSchema = z.object({
  packet_size: z.coerce.number().min(20).max(65535),
  duration: z.coerce.number().min(0).max(100),
  protocol: z.coerce.number().min(0).max(3),
  src_bytes: z.coerce.number().min(0).max(1000000),
  dst_bytes: z.coerce.number().min(0).max(1000000),
  flag: z.coerce.number().min(0).max(2),
  wrong_fragment: z.coerce.number().min(0).max(1),
  urgent: z.coerce.number().min(0).max(1),
});

type Props = {
  onSubmit: (data: TrafficData) => void;
  isAnalyzing?: boolean;
};

const DataInputForm = ({ onSubmit, isAnalyzing = false }: Props) => {
  const [useSampleData, setUseSampleData] = useState(false);

  // Normal traffic example
  const normalSample: TrafficData = {
    packet_size: 512,
    duration: 0.89,
    protocol: 1,
    src_bytes: 2000,
    dst_bytes: 1500,
    flag: 0,
    wrong_fragment: 0,
    urgent: 0,
  };

  // Suspicious traffic example
  const suspiciousSample: TrafficData = {
    packet_size: 32,
    duration: 8.5,
    protocol: 3,
    src_bytes: 15000,
    dst_bytes: 250,
    flag: 2,
    wrong_fragment: 1,
    urgent: 1,
  };

  // Initialize form
  const form = useForm<TrafficData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      packet_size: 0,
      duration: 0,
      protocol: 0,
      src_bytes: 0,
      dst_bytes: 0,
      flag: 0,
      wrong_fragment: 0,
      urgent: 0,
    },
  });

  const loadSample = (type: "normal" | "suspicious") => {
    const sample = type === "normal" ? normalSample : suspiciousSample;
    Object.entries(sample).forEach(([key, value]) => {
      form.setValue(key as keyof TrafficData, value);
    });
    setUseSampleData(true);
  };

  const handleRandomize = () => {
    // Generate random values based on reasonable ranges
    const randomData: TrafficData = {
      packet_size: Math.floor(Math.random() * 1500) + 60,
      duration: parseFloat((Math.random() * 10).toFixed(2)),
      protocol: Math.floor(Math.random() * 4),
      src_bytes: Math.floor(Math.random() * 10000),
      dst_bytes: Math.floor(Math.random() * 8000),
      flag: Math.floor(Math.random() * 3),
      wrong_fragment: Math.random() > 0.8 ? 1 : 0, // 20% chance of being 1
      urgent: Math.random() > 0.9 ? 1 : 0, // 10% chance of being 1
    };

    Object.entries(randomData).forEach(([key, value]) => {
      form.setValue(key as keyof TrafficData, value);
    });
    setUseSampleData(true);
  };

  return (
    <div className="bg-white dark:bg-slate-800 rounded-lg shadow-md border border-slate-200 dark:border-slate-700 overflow-hidden transition-all duration-200 hover:shadow-lg">
      <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-4 text-white">
        <h2 className="text-xl font-semibold flex items-center gap-2">
          <NetworkIcon className="h-5 w-5" />
          Traffic Metrics Input
        </h2>
        <p className="text-sm opacity-90">Enter network parameters to analyze</p>
      </div>
      
      <div className="p-5">
        <Alert className="mb-4 border-blue-200 bg-blue-50 text-blue-800 dark:border-blue-800 dark:bg-blue-950 dark:text-blue-200">
          <InfoIcon className="h-4 w-4" />
          <AlertTitle>Input Network Traffic Metrics</AlertTitle>
          <AlertDescription>
            Enter IIoT network traffic parameters to analyze for potential intrusions.
          </AlertDescription>
        </Alert>

        <div className="flex flex-wrap gap-2 mb-4">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => loadSample("normal")}
            disabled={isAnalyzing}
            className="border-green-200 text-green-700 hover:bg-green-50 dark:border-green-800 dark:text-green-400 dark:hover:bg-green-950"
          >
            <Database className="mr-2 h-4 w-4" />
            Load Normal Sample
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => loadSample("suspicious")}
            disabled={isAnalyzing}
            className="border-red-200 text-red-700 hover:bg-red-50 dark:border-red-800 dark:text-red-400 dark:hover:bg-red-950"
          >
            <BadgeAlert className="mr-2 h-4 w-4" />
            Load Suspicious Sample
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={handleRandomize}
            disabled={isAnalyzing}
          >
            <Shuffle className="mr-2 h-4 w-4" />
            Randomize Data
          </Button>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            {isAnalyzing ? (
              <div className="space-y-6 animate-pulse">
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                </div>
                <Skeleton className="h-10 w-full" />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                </div>
                <Skeleton className="h-12 w-full" />
              </div>
            ) : (
              <>
                <FormField
                  control={form.control}
                  name="packet_size"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Packet Size (bytes)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          placeholder="Enter packet size"
                          {...field}
                          className="focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        />
                      </FormControl>
                      <FormDescription>
                        Typical range: 60-1500 bytes
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="duration"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Connection Duration (seconds)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          step="0.01"
                          placeholder="Enter duration"
                          {...field}
                          className="focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="protocol"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Protocol Type</FormLabel>
                      <Select
                        onValueChange={(value) => field.onChange(parseInt(value))}
                        defaultValue={field.value.toString()}
                      >
                        <FormControl>
                          <SelectTrigger className="focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                            <SelectValue placeholder="Select protocol" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="0">TCP</SelectItem>
                          <SelectItem value="1">UDP</SelectItem>
                          <SelectItem value="2">ICMP</SelectItem>
                          <SelectItem value="3">Other</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="src_bytes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Source Bytes</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            placeholder="Enter source bytes"
                            {...field}
                            className="focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="dst_bytes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Destination Bytes</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            placeholder="Enter destination bytes"
                            {...field}
                            className="focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="flag"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Connection Flag</FormLabel>
                      <Select
                        onValueChange={(value) => field.onChange(parseInt(value))}
                        defaultValue={field.value.toString()}
                      >
                        <FormControl>
                          <SelectTrigger className="focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                            <SelectValue placeholder="Select flag" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="0">Normal</SelectItem>
                          <SelectItem value="1">Error</SelectItem>
                          <SelectItem value="2">Critical</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="wrong_fragment"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Wrong Fragment</FormLabel>
                        <Select
                          onValueChange={(value) => field.onChange(parseInt(value))}
                          defaultValue={field.value.toString()}
                        >
                          <FormControl>
                            <SelectTrigger className="focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                              <SelectValue placeholder="Select value" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="0">No (0)</SelectItem>
                            <SelectItem value="1">Yes (1)</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="urgent"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Urgent Packets</FormLabel>
                        <Select
                          onValueChange={(value) => field.onChange(parseInt(value))}
                          defaultValue={field.value.toString()}
                        >
                          <FormControl>
                            <SelectTrigger className="focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                              <SelectValue placeholder="Select value" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="0">No (0)</SelectItem>
                            <SelectItem value="1">Yes (1)</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <Button type="submit" 
                  className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 transition-all duration-300 shadow-md" 
                  size="lg"
                  disabled={isAnalyzing}
                >
                  <Zap className="mr-2 h-5 w-5" />
                  Analyze Traffic
                </Button>
              </>
            )}
          </form>
        </Form>
      </div>
    </div>
  );
};

export default DataInputForm;
